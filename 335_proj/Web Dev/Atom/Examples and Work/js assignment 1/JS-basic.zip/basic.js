function foo(){
  document.getElementsByTagName("h1")[0].innerHTML="Hello World!";

  window.alert ("Hello World!");
}
