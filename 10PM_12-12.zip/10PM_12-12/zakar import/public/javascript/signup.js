window.onload=function() {

  // Initialize Firebase
  const config = {
    apiKey: "AIzaSyBEUSx6m3y7QEgDvUBFjGus8vUQyJthhro",
    authDomain: "primchat-d585e.firebaseapp.com",
    databaseURL: "https://primchat-d585e.firebaseio.com",
    storageBucket: "primchat-d585e.appspot.com",
  };
  firebase.initializeApp(config);
  
  //Get elements
  const text_email = document.getElementById("email");
  const text_password = document.getElementById("password");
  const button_sign_up = document.getElementById("signup_button");

  //Add signup event
  button_sign_up.addEventListener('click', e => {
  	//Get email and password
  	// TODO: Check for real email
  	const email = text_email.value;
  	const password = text_password.value;
  	const auth = firebase.auth();
  	//Sign in
  	const promise = auth.createUserWithEmailAndPassword(email, password);

  	promise.catch(function(error) {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      // ...
    });
  });

  //Add a realtime listener
  firebase.auth().onAuthStateChanged(firebaseUser => {
  	if(firebaseUser) {
      console.log("User signed up.")
  		console.log(firebaseUser);
  	} else {
  		console.log("Not signed up.");
  	}
  });

};