(function() {

// Initialize Firebase
  const config = {
    apiKey: "AIzaSyBUd-l2uTWHqWW4Hm7NudDqQ6qaBidawBA",
    authDomain: "hackathonchatapp.firebaseapp.com",
    databaseURL: "https://hackathonchatapp.firebaseio.com",
    storageBucket: "hackathonchatapp.appspot.com",
  };
  firebase.initializeApp(config);

  //Add a realtime listener
  firebase.auth().onAuthStateChanged(firebaseUser => {
  	if(firebaseUser) {
  		console.log(firebaseUser);
  	} else {
  		console.log("Not logged in");
  	}
  });

}());