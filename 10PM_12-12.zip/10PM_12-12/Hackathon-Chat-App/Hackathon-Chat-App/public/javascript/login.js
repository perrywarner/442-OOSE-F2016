(function() {

// Initialize Firebase
  const config = {
    apiKey: "AIzaSyBUd-l2uTWHqWW4Hm7NudDqQ6qaBidawBA",
    authDomain: "hackathonchatapp.firebaseapp.com",
    databaseURL: "https://hackathonchatapp.firebaseio.com",
    storageBucket: "hackathonchatapp.appspot.com",
  };
  firebase.initializeApp(config);
  
  //Get elements
  const txtEmail = document.getElementById("email");
  const txtPassword = document.getElementById("password");
  const buttonLogin = document.getElementById("buttonLogin");
  const buttonSignUp = document.getElementById("buttonSignUp");
  const buttonLogout = document.getElementById("buttonLogout");

  //Add login event
  buttonLogin.addEventListener('click', e => {
  	//Get email and password
  	const email = txtEmail.value();
  	const password = txtPassword.value();
  	const auth = firebase.auth();
  	//Sign in
  	const promise = auth.signInWithEmailAndPassword(email, password);

  	promise.catch(e => console.log(e.message));

  });

  //Add a realtime listener
  firebase.auth().onAuthStateChanged(firebaseUser => {
  	if(firebaseUser) {
  		console.log(firebaseUser);
  	} else {
  		console.log("Not logged in");
  	}
  });

}());