var config = {
  apiKey: "AIzaSyDydc6Q1qd-4Sf3JRsOcVpVSFmTX8_lnPk",
  authDomain: "codes-out.firebaseapp.com",
  databaseURL: "https://codes-out.firebaseio.com",
  storageBucket: "codes-out.appspot.com",
  messagingSenderId: "977305217040"
};

var firebaseref = new Firebase("https://www.gstatic.com/firebasejs/3.6.3/firebase.js");

firebase.initializeApp(config);

$("#login-btn").on('click', function()
{
  var email = $("#login-email").val();
  var password = $("#login-password").val();
  firebaseref.authWithPassword({
    email: email,
    password: password
  },
  function(error, authData) {
    if(error) {
      console.log("Login Failed!", error);
    } else {
      console.log("Authenticated successfully with payload:", authData);
    }
  });
  console.log("hello world");
});

$("#signup-btn").on('click', function()
{
	var email = $("#email").val();
	var password = $("#password").val();
	firebaseref.createUser({
		email: email,
		password: password
	},function(error, userData) {
		if (error) {
			console.log("Error creating user:", error);
		}
		else {
			console.log("Successfully created user account with uid:", userData.uid);
			//additionally, you can log the user in right after the signup is successful and add more data about the user like name etc.
		}
	});
});

var authDataCallback = function(authData)
{
  if (authData) {
    console.log("User " + authData.uid + " is logged in");
  }
  else {
    console.log("User is logged out");
  }
};

firebaseref.onAuth(authDataCallback);
