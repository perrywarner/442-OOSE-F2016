window.onload=function() {
console.log("yes i'm loading something");
const config = {
  apiKey: "AIzaSyDydc6Q1qd-4Sf3JRsOcVpVSFmTX8_lnPk",
  authDomain: "codes-out.firebaseapp.com",
  databaseURL: "https://codes-out.firebaseio.com",
  storageBucket: "codes-out.appspot.com",
};

firebase.initializeApp(config);

const text_email = document.getElementById("email");
const text_password = document.getElementById("password");
const button_login_up = document.getElementById("login_button");
// const buttonSignup = document.getElementById("buttonSignUp");
// const buttonLogout = document.getElementById("buttonLogout");

//NEED a signup event
button_login_up.addEventListener('click', e => {
  //gets the email and password
  const email = text_email.value;
  const password = text_password.value;
  const auth = firebase.auth();

  //sign in (auth.signInWithEmailAndPassword) is a firebase event
  const promise = auth.signInWithEmailAndPassword(email, password);

  promise.catch(function(error) {
    //spit out errors. from firebase code
    var errorCode = error.code;
    var errorMessage = error.message;
  });

});

//event listener for firebase authorization state
firebase.auth().onAuthStateChanged(firebaseUser => {
  if(firebaseUser) {
      console.log("User logged in.");
      console.log(firebaseUser);
    } else {
      console.log("user not logged in.");
    }
});

};

// var authDataCallback = function(authData)
// {
//   if (authData) {
//     console.log("User " + authData.uid + " is logged in");
//   }
//   else {
//     console.log("User is logged out");
//   }
// };
//
// firebaseref.onAuth(authDataCallback);


// $("#login-btn").on('click', function()
// {
//   var email = $("#login-email").val();
//   var password = $("#login-password").val();
//   firebaseref.authWithPassword({
//     email: email,
//     password: password
//   },
//   function(error, authData) {
//     if(error) {
//       console.log("Login Failed!", error);
//     } else {
//       console.log("Authenticated successfully with payload:", authData);
//     }
//   });
//   console.log("hello world");
// });
//
// $("#signup-btn").on('click', function()
// {
// 	var email = $("#email").val();
// 	var password = $("#password").val();
// 	firebaseref.createUser({
// 		email: email,
// 		password: password
// 	},function(error, userData) {
// 		if (error) {
// 			console.log("Error creating user:", error);
// 		}
// 		else {
// 			console.log("Successfully created user account with uid:", userData.uid);
// 			//additionally, you can log the user in right after the signup is successful and add more data about the user like name etc.
// 		}
// 	});
// });

// var authDataCallback = function(authData)
// {
//   if (authData) {
//     console.log("User " + authData.uid + " is logged in");
//   }
//   else {
//     console.log("User is logged out");
//   }
// };
//
// firebaseref.onAuth(authDataCallback);
//}());
